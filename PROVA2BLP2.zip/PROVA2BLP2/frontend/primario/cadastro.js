import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { authenticateUser } from '../redux/açoes';
import { Button, Form } from 'react-bootstrap';

const Cadastro = () => {
  const dispatch = useDispatch();
  const [nickname, setNickname] = useState('');
  const [senha, setSenha] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    dispatch(authenticateUser(nickname, senha));
  };

  return (
    <div>
      <h2>Cadastro</h2>
      <Form onSubmit={handleSubmit}>
        <Form.Group>
          <Form.Label>Nickname</Form.Label>
          <Form.Control
            type="text"
            value={nickname}
            onChange={(e) => setNickname(e.target.value)}
            required
          />
        </Form.Group>
        <Form.Group>
          <Form.Label>Senha</Form.Label>
          <Form.Control
            type="password"
            value={senha}
            onChange={(e) => setSenha(e.target.value)}
            required
          />
        </Form.Group>
        <Button type="submit" variant="primary">Entrar</Button>
      </Form>
    </div>
  );
};

export default Cadastro;
