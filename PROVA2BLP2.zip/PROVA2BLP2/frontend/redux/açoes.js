import { getUsuarios, createUsuario, updateUsuario, deleteUsuario, verificarSenha, getMensagens, postMensagem, updateMensagem, deleteMensagem } from '../secundario/api.js';

export const setUsuarios = (usuarios) => ({
  type: 'SET_USUARIOS',
  payload: usuarios,
});

export const setMensagens = (mensagens) => ({
  type: 'SET_MENSAGENS',
  payload: mensagens,
});

export const addUsuario = (usuario) => async (dispatch) => {
  const data = await createUsuario(usuario);
  dispatch(setUsuarios([data, ...usuarios]));
};

export const authenticateUser = (nickname, senha) => async (dispatch) => {
  const response = await verificarSenha(nickname, senha);
  if (response.status && response.senhaCorreta) {
    dispatch({ type: 'USER_AUTHENTICATED', payload: { nickname } });
  } else {
    alert('Senha incorreta!');
  }
};

export const sendMessage = (mensagem) => async (dispatch) => {
  const data = await postMensagem(mensagem);
  dispatch(setMensagens([data, ...mensagens]));
};

export const changeMessageStatus = (id, lida) => async (dispatch) => {
  const response = await updateMensagem({ id, lida });
  dispatch(setMensagens(response.listaMensagens));
};

export const deleteMessage = (id) => async (dispatch) => {
  const response = await deleteMensagem(id);
  if (response.status) {
    dispatch(setMensagens(mensagens.filter(msg => msg.id !== id)));
  }
};

export const alterarMensagemLida = (id) => {
  return (dispatch) => {
      fetch(`/api/mensagens/${id}/marcar-lida`, {
          method: 'PUT',
          headers: {
              'Content-Type': 'application/json',
          },
          body: JSON.stringify({ lida: true }),
      })
      .then(response => response.json())
      .then(data => {
          dispatch({
              type: 'ALTERAR_MENSAGEM_LIDA',
              payload: data.mensagem,
          });
      })
      .catch((error) => {
          console.error('Erro ao marcar como lida:', error);
      });
  };
};

