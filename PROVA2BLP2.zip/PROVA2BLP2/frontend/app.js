import React, { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { setUsuarios } from './redux/açoes'; 
import { getUsuarios } from './secundario/api'; 
import Chat from './primario/chat.js';
import UserList from './primario/lista.js';  

const App = () => {
  const dispatch = useDispatch();

  useEffect(() => {
    const loadUsuarios = async () => {
      try {
        const usuarios = await getUsuarios();
        dispatch(setUsuarios(usuarios));
      } catch (error) {
        console.error("Erro ao carregar os usuários", error);
      }
    };

    loadUsuarios();
  }, [dispatch]);

  return (
    <div className="App">
      <Chat />
      <div className="user-list-container">
        <UserList />
      </div>
    </div>
  );
};

export default App;
