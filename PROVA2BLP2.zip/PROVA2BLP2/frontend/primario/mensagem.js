import React from 'react';
import { ListGroup, Button } from 'react-bootstrap';

const Message = ({ mensagem }) => {
  return (
    <ListGroup.Item>
      <strong>{mensagem.usuario}</strong>: {mensagem.mensagem}
      <Button variant="link" size="sm" className="float-end">Marcar como lida</Button>
    </ListGroup.Item>
  );
};

export default Message;
