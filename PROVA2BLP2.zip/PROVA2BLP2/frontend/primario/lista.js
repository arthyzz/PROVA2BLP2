import React from 'react';
import { useSelector } from 'react-redux';
import { ListGroup } from 'react-bootstrap';

const UserList = () => {
  const usuarios = useSelector((state) => state.usuarios);

  return (
    <div>
      <h2>Usuários Online</h2>
      <ListGroup>
        {usuarios.map((usuario) => (
          <ListGroup.Item key={usuario.id}>
            {usuario.nickname}
          </ListGroup.Item>
        ))}
      </ListGroup>
    </div>
  )};
