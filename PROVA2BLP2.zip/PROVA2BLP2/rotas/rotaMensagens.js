import { Router } from "express";
import  MensagemCTRL from "../controle/mensagemCTRL.js";

const rota = Router();
const mensagemCTRL = new MensagemCTRL();
rota.get("/", mensagemCTRL.consultar)
.get("/:termo", mensagemCTRL.consultar)
.post("/", mensagemCTRL.gravar)
.put("/", mensagemCTRL.alterar)
.patch("/", mensagemCTRL.alterar)
.delete("/", mensagemCTRL.excluir);

export default rota;

router.put('/:id/marcar-lida', (req, res) => {
    const id = req.params.id;
    const { lida } = req.body;

    if (lida === undefined) {
        return res.status(400).json({ mensagem: 'O status "lida" deve ser informado.' });
    }

    MensagemDAO.marcarComoLida(id, lida)
        .then(() => {
            res.status(200).json({ mensagem: 'Mensagem atualizada com sucesso!' });
        })
        .catch((error) => {
            res.status(500).json({ mensagem: 'Erro ao atualizar a mensagem: ' + error.message });
        });
});