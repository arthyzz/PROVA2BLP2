import axios from 'axios';

const API_URL = 'https://backend-bcc-2-b.vercel.app';

export const getUsuarios = async () => {
  const response = await axios.get(`${API_URL}/usuario`);
  return response.data.listaUsuarios;
};

export const createUsuario = async (usuario) => {
  const response = await axios.post(`${API_URL}/usuario`, usuario);
  return response.data;
};

export const updateUsuario = async (usuario) => {
  const response = await axios.put(`${API_URL}/usuario`, usuario);
  return response.data;
};

export const deleteUsuario = async (id, senha) => {
  const response = await axios.delete(`${API_URL}/usuario`, { data: { id, senha } });
  return response.data;
};

export const verificarSenha = async (nickname, senha) => {
  const response = await axios.post(`${API_URL}/usuario/verificarSenha`, { nickname, senha });
  return response.data;
};

// Mensagens
export const getMensagens = async () => {
  const response = await axios.get(`${API_URL}/mensagem`);
  return response.data.listaMensagens;
};

export const postMensagem = async (mensagem) => {
  const response = await axios.post(`${API_URL}/mensagem`, mensagem);
  return response.data;
};

export const updateMensagem = async (mensagem) => {
  const response = await axios.put(`${API_URL}/mensagem`, mensagem);
  return response.data;
};

export const deleteMensagem = async (id) => {
  const response = await axios.delete(`${API_URL}/mensagem`, { data: { id } });
  return response.data;
};
