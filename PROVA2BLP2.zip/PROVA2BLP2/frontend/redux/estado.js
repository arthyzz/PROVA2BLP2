const initialState = {
    usuarios: [],
    mensagens: [],
    user: null,
  };
  
  const rootReducer = (state = initialState, action) => {
    switch (action.type) {
      case 'SET_USUARIOS':
        return { ...state, usuarios: action.payload };
      case 'SET_MENSAGENS':
        return { ...state, mensagens: action.payload };
      case 'USER_AUTHENTICATED':
        return { ...state, user: action.payload };
      default:
        return state;
    }
  };
  
  export default rootReducer;
  