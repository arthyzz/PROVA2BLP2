import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Button } from "react-bootstrap";
import { excluirMensagem, buscarMensagens, enviarMensagem, alterarMensagemLida } from "../açoes";

const Chat = () => {
    const dispatch = useDispatch();
    const mensagens = useSelector(state => state.mensagens);
    const usuarioAtivo = useSelector(state => state.usuarioAtivo);
    const [mensagemInput, setMensagemInput] = useState("");

    useEffect(() => {
        dispatch(buscarMensagens());
    }, [dispatch]);

    const handleExcluir = (id, dataHora) => {
        const agora = new Date();
        const tempoPostagem = new Date(dataHora);
        const tempoDecorrido = (agora - tempoPostagem) / 1000 / 60;

        if (tempoDecorrido <= 5 && usuarioAtivo.nickname === id) {
            dispatch(excluirMensagem(id));
        } else {
            alert("Você não pode excluir esta mensagem.");
        }
    };

    const handleEnviarMensagem = () => {
        if (mensagemInput.trim() === "") {
            alert("Mensagem não pode ser vazia!");
            return;
        }

        const mensagem = {
            usuario: usuarioAtivo.nickname,
            mensagem: mensagemInput,
            dataHora: new Date().toLocaleString("pt-BR"),
            lida: false,
        };

        dispatch(enviarMensagem(mensagem));

        setMensagemInput("");
    };
    const marcarComoLida = (id) => {
        dispatch(alterarMensagemLida(id));
    };

    return (
        <div>
            <h2>Bate-papo</h2>
            <div>
                <textarea
                    value={mensagemInput}
                    onChange={(e) => setMensagemInput(e.target.value)}
                    placeholder="Digite sua mensagem aqui..."
                    rows={3}
                    style={{ width: "100%", marginBottom: "10px" }}
                />
                <Button
                    variant="primary"
                    onClick={handleEnviarMensagem}
                    disabled={!mensagemInput.trim()}
                >
                    Enviar
                </Button>
            </div>

            <div>
                {mensagens.map((mensagem) => {
                    const tempoPostagem = new Date(mensagem.dataHora);
                    const agora = new Date();
                    const tempoDecorrido = (agora - tempoPostagem) / 1000 / 60;

                    const podeExcluir = usuarioAtivo.nickname === mensagem.usuario && tempoDecorrido <= 5;

                    if (!mensagem.lida) {
                        marcarComoLida(mensagem.id);
                    }

                    return (
                        <div key={mensagem.id} style={{ marginBottom: "15px" }}>
                            <div>
                                <strong>{mensagem.usuario}</strong> - {mensagem.dataHora}
                            </div>
                            <div>{mensagem.mensagem}</div>

                            {podeExcluir && (
                                <Button
                                    variant="danger"
                                    onClick={() => handleExcluir(mensagem.id, mensagem.dataHora)}
                                    style={{ marginTop: "10px" }}
                                >
                                    Excluir
                                </Button>
                            )}
                        </div>
                    );
                })}
            </div>
        </div>
    );
};

export default Chat;
